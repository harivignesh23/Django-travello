from django.apps import AppConfig


class TourismConfig(AppConfig):
    name = 'tourism'
